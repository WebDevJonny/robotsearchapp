//because this is using export - it can have multiple exports but you have to destructer it {}
export const robots = [
    {
        id: 1,
        name: 'Jonny',
        username: 'Renzo',
        email: 'webdevjonny@example.com'
    },
    {
        id: 2,
        name: 'Fire Heat',
        username: 'fireheat10',
        email: 'fireheat@example.com'
    },
    {
        id: 3,
        name: 'Long Tribe',
        username: 'Longtribe11',
        email: 'longtribe@example.com'
    },
    {
        id: 4,
        name: 'Ocean Blue',
        username: 'Oceanb12',
        email: 'oceanblue@example.com'
    }
]